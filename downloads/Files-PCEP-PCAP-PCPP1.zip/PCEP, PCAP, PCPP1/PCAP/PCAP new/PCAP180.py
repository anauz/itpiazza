nums = [[1, 2], [3, 4], [5, 6]]
flat_nums = [x for sublist in nums for x in sublist if x % 2 == 0]
print(flat_nums)