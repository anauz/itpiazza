from math import e

# Using the constant e
print("The value of e is:", e)