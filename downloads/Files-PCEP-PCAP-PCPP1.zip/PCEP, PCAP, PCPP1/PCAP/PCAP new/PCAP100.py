class Animal:
    pass

class Cat(Animal):
    pass

obj = Cat()
print(isinstance(obj, Animal))