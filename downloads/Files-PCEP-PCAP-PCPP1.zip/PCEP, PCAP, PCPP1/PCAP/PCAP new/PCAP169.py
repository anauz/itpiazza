class Vehicle:
    def __init__(self, color, make):
        self.color = color
        self.make = make

    def start(self):
        print(f"The {self.color} {self.make} is starting.")


class Car(Vehicle):
    def __init__(self, color, make, num_doors):
        super().__init__(color, make)
        self.num_doors = num_doors

    def start(self):
        super().start()
        print(f"It has {self.num_doors} doors.")

v = Vehicle("blue", "Honda")
c = Car("red", "Ford", 4)

v.start()
c.start()