try:
    print("Is this possible?")
    print("#"[2])
    print("Yes!")
except:
    print("Execution failed")
print("DONE")