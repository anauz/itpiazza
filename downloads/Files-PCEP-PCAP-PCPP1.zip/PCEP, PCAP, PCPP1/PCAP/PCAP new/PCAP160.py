class A:
    def m1(self):
        print("m1 from A")

class B:
    def m1(self):
        print("m1 from B")

class C(A, B):
    pass

c = C()
c.m1()