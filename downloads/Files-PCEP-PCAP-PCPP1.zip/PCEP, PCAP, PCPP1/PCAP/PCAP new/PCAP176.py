class A:
    def __init__(self, v):
        self.__a = v + 2

a= A(40)
print(a.__a)