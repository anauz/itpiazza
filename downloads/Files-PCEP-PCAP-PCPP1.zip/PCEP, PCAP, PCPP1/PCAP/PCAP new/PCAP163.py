class A:
    def foo(self):
        print("A")

class B(A):
    def foo(self):
        print("B")
        super().foo()

class C(B):
    def foo(self):
        print("C")
        super().foo()

c = C()
c.foo()