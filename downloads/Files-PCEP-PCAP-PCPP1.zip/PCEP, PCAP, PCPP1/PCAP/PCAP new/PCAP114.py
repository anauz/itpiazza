class A:
    A = 1

class B(A):
    b = 1

print(hasattr(A, 'A'), end=",")
print(hasattr(B,'B'), end=",")
print(hasattr(B,'A'))