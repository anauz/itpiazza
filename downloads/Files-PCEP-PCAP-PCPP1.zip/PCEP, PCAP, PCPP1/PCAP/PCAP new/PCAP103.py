class Animal:
    def speak(self):
        print("The animal speaks.")

class Cat(Animal):
    def speak(self):
        print("Meow!")

animal = Animal()
animal.speak()