from math import e, exp, log

print(pow(e, 1) == exp(log(e)))
print(pow(3, 3) == exp(3 * log(3)))
print(log(e, e) == exp(0))

print(pow(e,1)) #2.718281828459045
print(exp(log(e))) #2.718281828459045
print(pow(3,3)) #27
print(exp(3 * log(3))) #a27
print(log(e, e)) #1.0
print(exp(0)) #1.0