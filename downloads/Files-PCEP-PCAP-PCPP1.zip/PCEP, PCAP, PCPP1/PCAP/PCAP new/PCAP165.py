class Animal:
    def make_sound(self):
        print("The animal makes a sound.")

class Dog(Animal):
    def make_sound(self):
        print("The dog barks.")

class Cat(Animal):
    def make_sound(self):
        print("The cat meows.")

def make_sounds(animals):
    for animal in animals:
        animal.make_sound()

animals = [Dog(), Cat(), Animal()]

make_sounds(animals)