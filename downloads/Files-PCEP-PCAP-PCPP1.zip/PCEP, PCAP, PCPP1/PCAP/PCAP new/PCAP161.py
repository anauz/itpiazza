class A:
    pass

class B:
    pass

class C(A):
    pass

obj = C()
print(isinstance(obj, B))