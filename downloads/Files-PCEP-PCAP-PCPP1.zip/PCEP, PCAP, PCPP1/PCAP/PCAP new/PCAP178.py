class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age


p = Person("Alice", 25)

p=Person(age=20, name="Dave")

