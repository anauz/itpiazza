class Customer:
    def get_details(self):
        print("Customer details")

    def get_orders(self):
        print("Customer orders")


class Supplier:
    def get_details(self):
        print("Supplier details")


class Partner(Customer, Supplier):
    pass


partner = Partner()
partner.get_details()