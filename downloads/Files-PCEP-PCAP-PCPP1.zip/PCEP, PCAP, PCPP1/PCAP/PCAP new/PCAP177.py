class Rectangle:
    def __init__(self, length=1, width=1):
        self.__length = length
        self.__width = width

    def set_length(self, length):
        self.__length = length

    def set_width(self, width):
        self.__width = width

    def area(self):
        return self.__length * self.__width

rect = Rectangle()
print(rect.set_length(5))

print(rect.area())