matrix = [[1, 2], [3, 4]]
result = [num**2 for row in matrix for num in row]
print(result)