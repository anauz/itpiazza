my_string = "Python is great!"
print(my_string.split()[::-1][0].rstrip("!"))