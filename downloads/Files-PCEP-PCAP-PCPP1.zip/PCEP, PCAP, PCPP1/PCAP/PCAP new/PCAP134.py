data = bytearray(b'hello world')
with open('output.txt', 'wb') as f:
    f.write(data)

with open('output.txt', 'rb') as f:
    buffer = bytearray(f.read())

print(buffer.decode())