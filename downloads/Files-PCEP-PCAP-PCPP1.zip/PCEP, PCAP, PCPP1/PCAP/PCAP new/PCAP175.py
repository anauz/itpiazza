class A:
    A = 1

class B:
    b = 1

class C(A, B):
    pass

print(hasattr(C, 'A'), end=",")
print(hasattr(C,'B'), end=",")
print(hasattr(B,'A'))