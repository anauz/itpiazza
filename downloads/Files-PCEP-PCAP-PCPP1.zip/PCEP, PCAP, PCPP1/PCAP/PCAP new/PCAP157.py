class MyClass:
    def __init__(self):
        self.my_var = 5

obj = MyClass()
print(hasattr(obj, '__init__'))
print(hasattr(obj, '__call__'))