try:
    num = int("abc")
except ValueError:
    print("Invalid input.")
except:
    print("An error occurred.")