def custom_func(x, y, operation):
    return operation(x, y)

result = custom_func(3, 4, lambda x, y: x * y)

print(result)