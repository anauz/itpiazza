class Person:
    def __init__(self, name):
        self.name = name
        self.age = 0

    def set_age(self, age):
        self.age = age

    def get_age(self):
        return self.age

    def print_info(self):
        print(f"Name: {self.name}")
        print(f"Age: {self.age}")


class Student(Person):
    def __init__(self, name, student_id):
        super().__init__(name)
        self.student_id = student_id

    def print_info(self):
        super().print_info()
        print(f"Student ID: {self.student_id}")


p = Person("Alice")
s = Student("Bob", 12345)

p.print_info()
s.print_info()