b = bytearray(2)
print(b)