my_string = "hello world"
print(my_string.replace("world", "python"))