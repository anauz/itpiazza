numbers = [1, 2, 3, 4, 5]
result = list(filter(lambda x: x % 2 == 1, numbers))
print(result)