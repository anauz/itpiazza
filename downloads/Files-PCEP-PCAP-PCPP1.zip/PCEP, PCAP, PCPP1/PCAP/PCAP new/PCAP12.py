print("a" > "")
print("8" > "10")
print("Mark">"MARK")