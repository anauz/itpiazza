class A:
    x=42

class B(A):
    x=56

class C(B):
    x=33

class D(C):
    pass

obj = D()
print(obj.x)