class MyException(Exception):
    def __init__(self, msg):
        self.msg = msg

try:
    raise MyException("This is a custom exception")
except Exception as e:
    print(e)