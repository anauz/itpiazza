class Animal:
    def __init__(self, name):
        self.name = name

    def speak(self):
        pass


class Cat(Animal):
    def __init__(self, name):
        super().__init__(name)

    def speak(self):
        print("Meow!")


class Dog(Animal):
    def __init__(self, name):
        super().__init__(name)

    def speak(self):
        print("Woof!")


a = Animal("Buddy")
c = Cat("Fluffy")
d = Dog("Max")

a.speak()
c.speak()
d.speak()