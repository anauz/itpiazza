s = "abc123"
for c in s:
    if c in "123":
        continue
    else:
        s = s.replace(c, "*")
print(s)