# Example of using *= and * operators with strings in Python
text = "hello"
multiplier = 3

# Use *= operator to repeat the string
text *= multiplier
print(text)  # Output: hellohellohello

# Use * operator to create a new string with repeated characters
new_text = "*" * 5
print(new_text)  # Output: *****