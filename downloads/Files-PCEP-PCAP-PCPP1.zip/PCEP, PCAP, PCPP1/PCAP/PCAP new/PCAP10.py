try:
    raise Exception(42, 0, 13, 44, "code")
except Exception as e:
    print(len(e.args))