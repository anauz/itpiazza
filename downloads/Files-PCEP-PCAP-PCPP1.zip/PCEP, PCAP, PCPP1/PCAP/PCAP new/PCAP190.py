# my_list = [1, 2, 3]
#
# try:
#     x = my_list[4]
# except IndexError:
#     print("IndexError occurred")
# except LookupError:
#     print("LookupError occurred")

my_list = [1, 2, 3]

try:
    x = my_list[4]
except LookupError:
    print("LookupError occurred")
except IndexError:
    print("IndexError occurred")