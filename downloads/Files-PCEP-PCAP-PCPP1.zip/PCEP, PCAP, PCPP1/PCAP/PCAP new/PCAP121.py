def make_multiplier(n):
    return lambda x: x * n

times_two = make_multiplier(2)
times_three = make_multiplier(3)

print(times_two(5))
print(times_three(7))