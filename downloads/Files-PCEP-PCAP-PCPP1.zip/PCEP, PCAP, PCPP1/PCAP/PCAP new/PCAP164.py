class Animal:
    def speak(self):
        print("The animal speaks.")

class Cat(Animal):
    def speak(self):
        print("Meow!")

def make_sound(animal):
    animal.speak()

animal = Animal()
cat = Cat()

make_sound(animal)
make_sound(cat)