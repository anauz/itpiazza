try:
    if '42' > 42:
        raise CustomError
    else:
        print('Else')
except CustomError:
    print('CustomError has occured.')
else:
    print('Oh no')