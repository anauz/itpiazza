s = "Hello world!"
index_position = s.index("o")  # Returns the index position of the first occurrence of 'o'
find_position = s.find("o")  # Returns the index position of the first occurrence of 'o'

print(f"Index position of 'o': {index_position}")
print(f"Find position of 'o': {find_position}")

# Now let's try to find a character that doesn't exist in the string:
try:
    index_position = s.index("z")
except ValueError:
    print("Index method raised ValueError: substring not found")

find_position = s.find("z")
if find_position == -1:
    print("Find method returned -1: substring not found")