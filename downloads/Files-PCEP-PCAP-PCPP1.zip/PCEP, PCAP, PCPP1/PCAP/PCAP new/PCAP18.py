s = "ProCoding"
print(sorted(s, reverse=True))