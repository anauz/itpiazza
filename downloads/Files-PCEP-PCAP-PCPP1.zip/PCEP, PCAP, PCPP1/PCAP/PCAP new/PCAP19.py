class Book:
    def __init__(self, title, author):
        self.title = title
        self.author = author

    def __str__(self):
        return f"{self.title} by {self.author}"

class Ebook(Book):
    def __init__(self, title, author, file_format):
        super().__init__(title, author)
        self.file_format = file_format

    def __str__(self):
        return f"{super().__str__()} [{self.file_format}]"

book1 = Book("The Catcher in the Rye", "J.D. Salinger")
book2 = Ebook("To Kill a Mockingbird", "Harper Lee", "PDF")

print(book1)
print(book2)