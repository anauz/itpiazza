def custom_func(numbers, condition):
    return [n for n in numbers if condition(n)]

result = custom_func([1, 2, 3, 4, 5], lambda x: x % 2 == 0)

print(result)