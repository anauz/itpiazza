class Parent:
    def display(self):
        print("Parent")

class Child(Parent):
    def display(self):
        print("Child")

p = Parent()
p.display()

c = Child()
c.display()