class B():
    def __init__(self, lst):
        self.lst = lst
        self.i = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.i == len(self.lst):
            raise StopIteration
        v = self.lst[self.i]
        self.i += 1
        return v

b = B([1, 2, 3, 4])
for x in b:
    print (x, end="")