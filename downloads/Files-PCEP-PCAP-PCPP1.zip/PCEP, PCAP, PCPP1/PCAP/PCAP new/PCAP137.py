import os
os.mkdir('new_directory')
os.chdir('new_directory')
os.mkdir('subdirectory')
os.chdir('subdirectory')
print(os.getcwd())