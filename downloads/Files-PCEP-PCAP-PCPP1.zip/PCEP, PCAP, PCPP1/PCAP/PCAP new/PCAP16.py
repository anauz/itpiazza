s = "this is a string"
print(s[2:8])