class A:
    x = 0

    def __init__(self):
        A.x += 1

a1 = A()
a2 = A()
a3 = A()

print(a3.x)