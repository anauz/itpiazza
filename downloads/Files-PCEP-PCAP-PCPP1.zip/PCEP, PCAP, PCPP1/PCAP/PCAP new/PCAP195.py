x = input("Enter a value: ")
print(42.0/x)