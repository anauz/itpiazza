numbers = [1, 2, 3, 4, 5]
square = lambda x: x ** 2
result = map(square, numbers)
print(list(result))