print("Ana">"ana")
print("20"<"8")
print(""<"Z")
print("">" ")