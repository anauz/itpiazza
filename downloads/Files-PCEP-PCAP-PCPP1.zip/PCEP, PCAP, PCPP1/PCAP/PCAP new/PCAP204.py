s = 'hello world'
s = s[:5].replace('o', 'O') + s[6:]
print(s.split())