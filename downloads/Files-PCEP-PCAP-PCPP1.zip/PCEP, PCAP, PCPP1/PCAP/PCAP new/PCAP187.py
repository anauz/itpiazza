try:
    assert 2 + 2 == 5, "This is an assertion error"
except AssertionError:
    print("Caught an AssertionError")