try:
    raise Exception
except BaseException:
    print("r", end="")
except Exception:
    print("p", end="")
except:
    print("o", end="")