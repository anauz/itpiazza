class Animal:
    pass

class Cat(Animal):
    pass

print(Cat.__module__)