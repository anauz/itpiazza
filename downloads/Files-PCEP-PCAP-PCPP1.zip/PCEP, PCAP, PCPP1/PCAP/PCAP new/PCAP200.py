my_string = "hello world"
print(my_string.center(20, "*"))