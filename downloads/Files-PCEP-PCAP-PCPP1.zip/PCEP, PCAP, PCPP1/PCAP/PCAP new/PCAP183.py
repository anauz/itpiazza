letters = ["a", "b", "c"]
result = [letter*2 for letter in letters if letter!="b"]
print(result)