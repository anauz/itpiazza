try:
    num = int(input("Enter a number: "))
    assert num > 0, "Number must be positive"
except ValueError:
    print("Invalid input.")
else:
    print("Number is positive")
finally:
    print("Execution complete")