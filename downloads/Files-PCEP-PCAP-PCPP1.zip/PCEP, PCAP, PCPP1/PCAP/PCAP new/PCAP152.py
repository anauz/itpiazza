import math

x = -4.7
print(-abs(math.floor(x) + math.ceil(x))+ math.trunc(x))

print(math.floor(x))  #-5
print(math.ceil(x)) #-4
print(-abs(math.floor(x) + math.ceil(x))) #-9
print(math.trunc(x)) #-4
