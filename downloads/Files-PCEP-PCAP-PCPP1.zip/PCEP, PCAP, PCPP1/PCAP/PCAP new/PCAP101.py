class A:
    def __init__(self, a):
        self.a = a

    def __eq__(self, other):
        return self.a == other.a

obj1 = A(5)
obj2 = A(5)

print(obj1 == obj2)
print(obj1 is obj2)
