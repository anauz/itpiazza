class MyException(Exception):
    def __init__(self, msg):
        super().__init__(msg)

try:
    raise MyException("This is a custom exception")
except Exception as e:
    print(e)