class A:
    x = 5

class B(A):
    pass

class C(A):
    x = 10

class D(B, C):
    pass

obj = D()
print(obj.x)