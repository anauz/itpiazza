numbers = [1, 2, 3, 4, 5]
result = filter(lambda x: x % 3 == 0, map(lambda x: x ** 2, numbers))
print(list(result))