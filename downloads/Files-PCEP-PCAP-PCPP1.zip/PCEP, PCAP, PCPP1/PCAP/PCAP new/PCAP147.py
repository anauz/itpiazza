import math

def cos(x):
    if 4 * x == pi:
        return 0.9
    else:
        return None

pi = 3.14

print(cos(pi/4))
print(math.cos(math.pi))