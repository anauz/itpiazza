alphabet = "abcdefghijklmnopqrstuvwxyz"

print("f" in alphabet) #True
print("F" in alphabet) #False

#del alphabet[0] produces an error

#alphabet.append("A")
#AttributeError: 'str' object has no attribute 'append'

del alphabet #deletes the whole string
#print(alphabet) #doesn't exist anymore

