class A:
    def __str__(self):
        return 'a'

class B:
    def __str__(self):
        return 'b'

class C(B):
    pass

obj =  C()
print(obj)