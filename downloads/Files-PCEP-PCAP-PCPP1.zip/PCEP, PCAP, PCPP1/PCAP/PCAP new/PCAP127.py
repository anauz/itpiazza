import sys

numbers = [1, 2, 3, 4, 5]

for n in numbers:
    sys.stdout.write(str(n))