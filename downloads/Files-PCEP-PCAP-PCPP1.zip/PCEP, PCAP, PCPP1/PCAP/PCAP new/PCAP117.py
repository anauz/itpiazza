class Class:
    def __init__(self):
        pass

obj=Class()