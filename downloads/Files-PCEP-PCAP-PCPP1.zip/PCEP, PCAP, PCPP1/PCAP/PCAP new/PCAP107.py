class Shape:
    def __init__(self, color):
        self.color = color


class Square(Shape):
    def __init__(self, side):
        self.side = side


s = Square(5)
print(s.color)