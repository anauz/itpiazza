def outer_function(x):
    def inner_function(y):
        return x * y
    return inner_function

result1 = outer_function(5)
result2 = outer_function(10)
print(result1(3), result2(3))