s = "abc123"
if s.isalnum():
    s = s.replace("1", "")
if "3" in s:
    s = s + "!"
else:
    s = s.upper()
print(s)