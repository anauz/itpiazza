my_string = "   Python is awesome!   "
print(my_string.strip().replace(" ", "-"))