a, b = 42.0, 0
try:
    c = a / b
except ZeroDivisionError:
    c = 2
except ArithmeticError:
    c = 1
else:
    c = 3
print(c)