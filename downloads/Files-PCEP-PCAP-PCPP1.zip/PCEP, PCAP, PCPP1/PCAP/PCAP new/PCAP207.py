str1 = 'x'
str2 = 'y'

print(str1 + str2)
print(str2 + str1)
print(5 * str1)
print(str2 * 4)