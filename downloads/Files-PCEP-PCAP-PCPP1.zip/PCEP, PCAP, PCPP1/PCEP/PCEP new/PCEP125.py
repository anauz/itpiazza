def test(x):
  return 42 if x % 3 != 0 else 13

#print(100 % 3 != 0) #True

#print(42 % 3 != 0) #False

print(test(test(100)))

#print(test(42)) #13
