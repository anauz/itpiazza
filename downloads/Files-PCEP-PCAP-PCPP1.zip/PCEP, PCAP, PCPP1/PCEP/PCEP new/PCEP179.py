data=[57, 45, 23, 1, 9, 2, 4]
data.pop() #removes the last element [57, 45, 23, 1, 9, 2]
data.pop(1) #removes element with index 1 [57, 23, 1, 9, 2]
data.pop(2) #removes element with index 2 [57, 23, 9, 2]
print(data)
