def fun(procoding):
  #print(procoding) #prints 42 but also None!!!
  #print('procoding') #prints 'procoding' and None!!!
  #return 'procoding' #prints 'procoding'
  return procoding # works ok and 42 would be printed
print(fun(42))
