# Mutable object: list
my_list = [1, 2, 3]
print("Original list:", my_list)

# change list
my_list[0] = 4
print("Changed list:", my_list)

# Immutable object: string
my_string = "Hello, World!"
print("Original string:", my_string)

# try to change string
try:
    my_string[0] = "h"
except TypeError as e:
    print("Cannot change string:", e)
