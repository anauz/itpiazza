print(list('PROcoding'))
