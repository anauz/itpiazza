x = 42
y = x
x = 43
print(y)
