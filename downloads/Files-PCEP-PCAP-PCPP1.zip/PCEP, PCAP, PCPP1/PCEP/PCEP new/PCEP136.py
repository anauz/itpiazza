def funct(x=13, y=42, z=0):
  x = x + y + z #x=3+2+1 x=6
  y -= 11 #y=2-11 y=-9
  z +=10 #z=1+10 z=11
  print(x, y, z) #6 -9 11
  
funct(3, 2, 1)
