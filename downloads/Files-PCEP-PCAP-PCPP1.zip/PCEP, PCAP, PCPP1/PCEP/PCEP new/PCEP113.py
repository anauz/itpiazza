#True=6

#1ok=7

not_ok=8

_python=9

_1x=10

print(not_ok)
print(_python)
print(_1x)
