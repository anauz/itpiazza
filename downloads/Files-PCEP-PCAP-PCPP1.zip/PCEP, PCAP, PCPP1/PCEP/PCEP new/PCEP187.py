i = 7
while i <= 42:
  i += 13
  print('*','*', sep=',', end='')
