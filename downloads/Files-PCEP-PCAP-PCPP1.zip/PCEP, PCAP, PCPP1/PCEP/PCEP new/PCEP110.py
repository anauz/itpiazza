def f(x):
  x=['a', 'b', 'c', 'd', 'e']
  print(x)

x=['p','q','r']
f(x)
print(x)
