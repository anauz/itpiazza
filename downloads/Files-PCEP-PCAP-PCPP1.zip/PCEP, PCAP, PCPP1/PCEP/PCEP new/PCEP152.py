d = {'one': 'four', 'four': 'two', 'two': 'three', 'three':'one'}
v = d['one']
print(v) #four
for k in range(len(d)): #range(4)
 v = d[v]
 print(v)

print(v)
