x = {}
x['a'] = ('a', 'b', 'c')
x['b'] = ('b', 'a', 'c')
x['c'] = ('c', 'a', 'b')

for el in x.keys():
  print(x[el][2], end='')
