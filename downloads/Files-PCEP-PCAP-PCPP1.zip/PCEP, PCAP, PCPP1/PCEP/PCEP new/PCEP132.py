x = 42
def test():
  #x = x % 4  # UnboundLocalError: ...local variable 'x' referenced before assignment
  print(x)
test()
print(x)

y = 42
def test2():
  x = y % 4
  print(x)  # 2
test2()
