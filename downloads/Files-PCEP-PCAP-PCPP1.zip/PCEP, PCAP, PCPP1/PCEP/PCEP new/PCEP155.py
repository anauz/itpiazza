a = 'DataScience4U'
i = 7
while i < len(a):
  i += 2
print(i+1)
