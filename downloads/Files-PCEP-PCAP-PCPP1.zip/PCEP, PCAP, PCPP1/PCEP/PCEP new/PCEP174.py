x = 42
if (x<13): print("Yes")
else: print("No")
