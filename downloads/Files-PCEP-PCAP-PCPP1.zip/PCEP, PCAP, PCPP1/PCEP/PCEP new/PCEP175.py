data=""
while data:
 print("Data is not empty")
else:
  print("Data is empty")
