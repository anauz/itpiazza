def f():
  x=2
  y=3
  return x+y
x = f(5) #TypeError f() takes 0 positional arguments but 1 was given
print(x)
