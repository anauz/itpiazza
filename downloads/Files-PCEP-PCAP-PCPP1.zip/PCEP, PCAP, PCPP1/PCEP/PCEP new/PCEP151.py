sum = 0
num = 0
ok = True
agp = 0.0
failed = 0

while ok:
  mark = float(input('Enter next mark (5-10), 0 for done: '))
  if mark == 0:
    break
  if mark == 5:
    failed += 1
  else:
    sum += mark
    num += 1
    
agp = float(sum / num)

print('The agp for student is: ', format(agp, '.2f'))
if (failed!=0):
  print("The student has failed ", str(failed), "exam(s)!")
