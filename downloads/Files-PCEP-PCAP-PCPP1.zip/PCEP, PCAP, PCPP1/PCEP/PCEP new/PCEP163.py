data = {}
data[0] = 'Math'
data['Languages'] = ['English', 'Serbian']
print(data)
