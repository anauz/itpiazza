if not 1:
  print("Hay")
else:
  print("Ho")
