tuple = 42,13,7,'13'
print(list(tuple))
