x='Procoding'
y=0
while y<len(x):
  y+=1
  pass
print("y: ", y)
