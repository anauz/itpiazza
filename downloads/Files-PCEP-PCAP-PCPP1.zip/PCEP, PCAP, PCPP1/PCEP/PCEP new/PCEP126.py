def test(x, y, z):
  return x - 2 ** y + 4 * z

#print(2**5) #32
#print(4*5) #20
#print(0 - (2 ** 5) + (4 * 2))
#print(0-32+8)
#print(-24)
print(test(0, z=2, y=5))
