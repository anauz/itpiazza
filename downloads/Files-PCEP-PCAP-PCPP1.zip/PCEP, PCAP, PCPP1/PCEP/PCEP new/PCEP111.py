x = float(input('Enter a float: '))
print('You entered ' + x) #TypeError... can only concatenate str (not "float") to str
