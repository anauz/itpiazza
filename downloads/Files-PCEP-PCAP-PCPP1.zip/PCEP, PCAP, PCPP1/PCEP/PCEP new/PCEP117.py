#for = 17  # SyntaxError: invalid syntax
input = 46
print = 42
Print=10
#print(input)  TypeError: 'int' object is not callable
#print(print)  TypeError: 'int' object is not callable
#print(Print)  TypeError: 'int' object is not callable
