try:
    # code that may raise an exception
    x = 1/0
except ZeroDivisionError:
    # handling division by zero exception
    print("Division by zero error")
except Exception as e:
    # handling any other exception
    print("An error occurred:", str(e))
