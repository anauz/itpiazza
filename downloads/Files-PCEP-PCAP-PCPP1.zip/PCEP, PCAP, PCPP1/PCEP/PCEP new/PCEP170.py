def change(a, b):
  a, b = b, a
a = 13
b = 42
change(a, b)
print(a, b)
