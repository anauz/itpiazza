x = 42

if x > 10 or not x >= 42:
  print("Hey", end="-")
if x > 42:
  print("Hee", end="-")
elif x >= 42:
  print("Hi", end="-")
else:
  print("Ho", end="-")
