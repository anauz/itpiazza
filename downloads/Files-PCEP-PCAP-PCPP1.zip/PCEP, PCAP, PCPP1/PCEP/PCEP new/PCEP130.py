def f1():
  x=3
  
print(f1())  # None
