var=0
for i in range(3):
  for j in range(-2, -7, -2):
    var+=1
print (var)
