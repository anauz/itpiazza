x = 5
def f():
  global x
  x += 5
  print(5 + x)
print(x)
f()
print(x)
