x = 42
if x != 13:
  print("*",end=',')
  if x < 7:
    print(">")
  elif x == 20:
    print(">>")
  else:
    print("+" * 3)
else:
  print("- 2" * 2)
