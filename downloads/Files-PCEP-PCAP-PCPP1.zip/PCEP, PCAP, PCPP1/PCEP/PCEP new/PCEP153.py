def f(data):
  for d in data[::3]:
    yield d
    
for x in f('DataScience4U'):
  print(x, end=' ')
