x=8
y=10
z=12
if x<y:
  if x<z:
    print("the smallest number is: ", x)
elif y<x:
  if y<z:
    print("The smallest number is: ", y)
elif z<x:
  if z<y:
    print("The smallest number is: ", z)
else:
  print("else")
