def f1():
  c=30,
  d=20,
  return c, d

a,b=f1()
print(a,b)
