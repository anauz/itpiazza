x = [[[42, 13], [33, 44]], [[555, 678], [7, 8]]]

def test(z):
  res = z[0][0]
  for el in z:
    for d in el:
      if res < d:
        res = d
  return res

print(test(x[1]))
