x = int(input('Enter a number'))
print(1/x)
