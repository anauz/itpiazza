print(DataScience4U, Procoding, sep=",") #NameError: name 'DataScience4U' is not defined
