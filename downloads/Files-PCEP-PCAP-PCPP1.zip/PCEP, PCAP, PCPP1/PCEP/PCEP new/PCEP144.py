def mystery_function(lst):
    if len(lst) == 0:
        return []
    if len(lst) == 1:
        return lst
    return mystery_function(lst[1:]) + [lst[0]]

original_list = [1, 2, 3, 4, 5]
result = mystery_function(original_list)
print("Original list:", original_list)
print("Result:", result)
