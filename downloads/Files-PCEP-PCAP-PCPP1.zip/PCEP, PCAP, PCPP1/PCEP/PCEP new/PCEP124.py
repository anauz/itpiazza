x = False
y = False
z = True

if not x or not y:
#if ((not (False)) or (not (False)))
#if (True or True)
#if True #the condition is true, the print will execute
  print(1)
elif not x or not y and z:
# ((not(False)) or ((not(False)) and (True)))
# (True or (True and True))
# True or True
# True
#altough it is true, this will not execute, as if condition was met
  print(2)
elif x or y or not y and not x:
# (False or False or ((not (False)) and (not (False))))
# (False or False or (True and True))
# (False or False or True)
# ((False or False) or True)
# False or True
# True 
# altough it is true, this will not execute, as if condition was met
  print(3)
else:
  print(4)
