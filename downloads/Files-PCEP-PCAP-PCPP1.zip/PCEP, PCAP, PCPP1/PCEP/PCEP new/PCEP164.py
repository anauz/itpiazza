d = [3, 5, 2]
d.insert(1, 2)
d.append(3)
print(d)
