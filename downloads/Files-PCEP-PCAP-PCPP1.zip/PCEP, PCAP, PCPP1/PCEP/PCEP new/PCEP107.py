list=['p', 'q', 'r']
def f(char):
  char.pop()
  char.append('s')
  print(char)
f(list)
print(list)
