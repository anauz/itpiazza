def f(x):
  res = '*'
  for _ in range(x):
    res += res
  return res

for x in f(3):
  print(x, end='-')
