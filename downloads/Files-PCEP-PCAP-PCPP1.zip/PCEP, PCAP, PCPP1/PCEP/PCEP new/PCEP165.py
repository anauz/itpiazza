for x in range(3, 13, 2): #3 6 9 12
  print(x, end = ",")
