x = 42
y = 13
x, y, z = x, x, y #x, y, z = 42, 42, 13
#x=42
#y=42
#z=13
print (x, y, z)
z, y, z = x, y, z #z, y, z = 42, 42, 13
#z=42
#y=42
#z=13

print(x,y,z)
