sport="judo"
for i in range (0, len(sport)):
  print(sport[i])
