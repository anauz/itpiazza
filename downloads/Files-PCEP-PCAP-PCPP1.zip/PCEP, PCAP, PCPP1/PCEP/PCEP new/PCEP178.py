x = ['Procoding', 42, 13.03, 'DataScience', '4U', 11.1]
print(x[1:4])
