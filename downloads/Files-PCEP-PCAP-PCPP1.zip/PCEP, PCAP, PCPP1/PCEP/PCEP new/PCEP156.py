animals = {'Tom': 10, 'Jerry': 20}
print(animals[20])
