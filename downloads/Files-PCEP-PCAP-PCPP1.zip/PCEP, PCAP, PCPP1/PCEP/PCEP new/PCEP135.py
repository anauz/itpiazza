num1 = 1
num2 = 0
num3 = not(num1 and num2)
num4 = num1 or not num2
print(num3 + num4)

print("*******************")

print(not(num1 and num2)) #True
print(not(1 and 0)) #0 #print(1 and 0)=0
print(not (0)) #True
print (True) #True

print("******************")

print(num1 or not num2) #
print(1 or not 0) #1 
print(1 or (not 0)) #1
print (1 or 1) #1
print (1) #1

print(num3 +num4) #print (True+1)=2
print(True +1) #2
