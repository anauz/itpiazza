x = [False, True, "42", 3, 4, 5]
a=42 in x
print(a, end=" ") #False
b=0 in x
print(b) #True
