def test(a, b, c=0, d=4):
  # Body of the function.
  pass

test(b=4, a=7) #correct as c and d have predifined values
#test(a=6, c=7, d=4) #TypeError: test() missing 1 required positional argument: 'b'
#test(c=2, d=2) #TypeError: test() missing 2 required positional arguments: 'a' and 'b'
#test() #TypeError: test() missing 2 required positional arguments: 'a' and 'b'
