def test(text, x):
  while x >= 0:
    print(text, end=" ")
  x = x - 2
  
test('Procoding', 7)
