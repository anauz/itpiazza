d = {}
d[1] = 7
d['1'] = 8
d[1] -=  4 #the now value for index 1 will be 3

s = 0

for i in d:
    s += d[i] #s=3+8
    
print(s)
