for i in range(0, 4): #correct
  print(str(i+1) * 6)
  
print("*********")

for i in range(1, 5): #incorrect
  print(str(i+1) * 6)
  
print("********")  #incorrect
for i in range(0, 4):
  print(str(i+1) * 6)
  
print("********") #incorrect
for i in range(1, 4):
  print(str(i) * 6)
  
for i in range(0, 4): #incorrect as you get extra space between numbers
  print(str(i+1),str(i+1),str(i+1),str(i+1),str(i+1),str(i+1))
