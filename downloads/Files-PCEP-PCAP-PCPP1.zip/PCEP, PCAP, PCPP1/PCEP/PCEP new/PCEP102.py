serbian_greeting ="Zdravo"

for i in serbian_greeting:
 if i=="a":
    pass
else:
  print('Hello')
