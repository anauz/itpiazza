i = -7
while i <= 3:
  i += 2
  if i % 3 == 0:
    break
  print("*", end="")
