x = 'DataScience4U'
for char in x:
  if char == 't':
    break
  print(char)
else:
  print('Finished!')
