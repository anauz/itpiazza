def func(a):
  a[3]='shark'
  
x = ['cat', 'dog', 'mouse', 'cow']
func(x)
print(x)
