sports = ['basketball', 'judo', 'tennis', 'football']
for sport in sports:
  if sport != 'judo':
    print(sport, end=',')
