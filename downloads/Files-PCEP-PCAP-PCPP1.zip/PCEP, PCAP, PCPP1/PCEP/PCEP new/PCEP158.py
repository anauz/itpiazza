for i in range(4):
  for j in range(10):
    if i == j:
      print(i+j, end=' ')
