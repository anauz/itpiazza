a = 13
b = 42

c = a < b and b > a or b > a and a < b

print(c)

print('*****************')

print (((a < b) and (b > a)) or ((b > a) and (a < b))) #True
print (((13 < 42) and (42 > 13)) or ((42 > 13) and (13 < 42))) #True
print ((True and True) or (True and True)) #True
print (True or True) #True
print (True) #True
