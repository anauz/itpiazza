a = input() #a="4"
b = input() #b="2"
print(a + b) #+ performs concatenation and the result is "42"
