def f(x):
  for i in range(7):
   yield i
   
print(list(f(13)))
