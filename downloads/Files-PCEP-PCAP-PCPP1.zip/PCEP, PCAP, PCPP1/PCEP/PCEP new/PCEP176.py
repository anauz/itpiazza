x=42
while x<46:
  x+=1
  print(x)
  break
else:
  print("break")
