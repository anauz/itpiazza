year = 2000
print("Year is less than 2023") if year<2023 else print("Bye bye")
