def f(x):
    x[0] = 42
    
x = [1, 2, 3, 4]
f(x)
print(x)
