x = (1, 2)
y = ('x', 'y', 42)
z = x + y * 2
print(z)
