def f(x):
  if x%2 == 0:
    return True
  else:
    return False

print(not f(2) or f(2) and f(7))
