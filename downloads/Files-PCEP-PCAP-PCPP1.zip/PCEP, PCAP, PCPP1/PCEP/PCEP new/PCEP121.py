i = 9
while i > 0:
  i -=  3#i will have values 6, 3
  print('*') #this will be executed when i is 6 and 3, two stars
  #print(i)
  if i == 3:
    break
  else:
    print('*') #this will be executed when i is 6, one star
