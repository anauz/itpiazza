str="Hello"
def f():
  global str
  str=str*4
  print(str)
  
f()
print(str)
