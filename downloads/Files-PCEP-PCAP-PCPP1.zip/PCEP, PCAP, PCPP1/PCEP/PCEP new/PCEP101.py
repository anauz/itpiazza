priority = float(input())
if (priority == 1):
  print("FR")
elif (priority==2):
  print("GR")
elif (priority==3):
  print("EN")
else:
  print("None")
