x = [0, 7, 42]
x.insert(0, 1)
del x[1]
print(sum(x))
