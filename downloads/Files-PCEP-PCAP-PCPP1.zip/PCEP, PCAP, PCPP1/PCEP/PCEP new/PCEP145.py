def average_of_evens(numbers):
    total = 0
    count = 0
    for num in numbers:
        if num % 2 == 0:
            total += num
            count += 1
    if count == 0:
        return None
    else:
        return total / count
    
print(average_of_evens([1,2,3,4,5,16,17]))
