# You can assign None value to a variable
x = None
print(x) # None

# The None value can be compared to other variables.
y = 3
print(y is None)  # False

# The None value cannot be used
# as an argument of arithmetic operators:
# print(None + 7)  # TypeError: unsupported operand ...
