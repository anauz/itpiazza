x=123
def f(y):
  sum=0
  while (y!=0):
    sum+=int(y%10)
    y=int(y/10)
  print(sum)
f(x)
