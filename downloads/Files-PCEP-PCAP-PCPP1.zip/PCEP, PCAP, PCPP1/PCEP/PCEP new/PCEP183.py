data = [1, 2, 3, 4, 5]

def test(x):
  del x[0]
  x.pop(2)
  
test(data)
print(data)
