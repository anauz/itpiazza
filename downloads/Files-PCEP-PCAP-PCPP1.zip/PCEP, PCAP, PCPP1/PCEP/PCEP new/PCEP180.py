try:
  print(42/0)
  continue
except (ZeroDivisionError):
  print("Zero division")
except:
  print("You made a mistake")
except (ValueError):
  print("Boo!")
