x = 42
y = 4
print(x / y) #10.5
print(x // y) #10
print(x % y) #2
