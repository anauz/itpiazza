def test(a, b):
  a = 1
  b[0] = 42
  
x = 13
y = [10, 20, 30]

test(x, y)

print(x, y[0])
