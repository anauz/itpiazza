voltage = 1
while voltage < 4:
    voltage += 1
    print("#", end="")
    if voltage == 3:
        break
else:
    print("#")
