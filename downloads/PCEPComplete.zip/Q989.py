def update(value):
    return counter + value

counter = 3
new_counter = update(4)
new_counter = update(counter)
print(new_counter)
