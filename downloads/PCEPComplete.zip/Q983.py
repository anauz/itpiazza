# Define a dictionary
my_dict = {"key1": "value1", "key2": "value2"}

# Try to access a nonexistent key and handle the KeyError
try:
    value = my_dict["nonexistent_key"]
except KeyError:
    print("Handled a KeyError")
except:
    print("Unhandled exception")
