def modify(list_data):
    list_data = [5, 6, 7]
    return list_data[1]

values = [9 for i in range(3)]
modify(values)
print(values[1])