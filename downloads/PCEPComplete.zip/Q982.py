city_population = {"Tokyo": 37435191, "Delhi": 29399141, "Shanghai": 26317104}

for population in city_population.values():
    print(str(population)[0], end="")
