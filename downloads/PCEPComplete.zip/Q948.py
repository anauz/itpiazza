list_a = [4, 5]
list_b = list_a
list_b.insert(1, 6)
print(list_a[1])