car_speed = {"Ferrari": 340, "Lamborghini": 350, "Porsche": 320}

for car in car_speed:
    print(car[0], end="")