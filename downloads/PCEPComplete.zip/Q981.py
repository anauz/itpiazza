# Define the student_grades dictionary
student_grades = {
    "Alice": 95,
    "Bob": 88,
    "Charlie": 92
}

# Retrieve the grade of Alice and assign it to the grade variable
grade = student_grades["Alice"]

# Print the retrieved grade
print("Alice's grade:", grade)
