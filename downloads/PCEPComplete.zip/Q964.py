print(5 % 3 - 1) #1
print(2 // 3 * 3) #0
print(3 // 4 + 1 - 1) #0
print(4 - 2 * 2 // 4) #3