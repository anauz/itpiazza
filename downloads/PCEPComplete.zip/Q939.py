stars = 4 - 2 ** 2 + 1
if stars > 0:
    print("A")
elif stars > 1:
    print("AA")
else:
    print("AAA")
