temp = (5 * 4) + (8 // 2) - 3 + (10 % 3) * 7

if temp == 42:
    print("#")
elif temp > 50:
    print("##")
else:
    print("###")
# prints ###

if temp < 30:
    print("#")
elif temp > 50:
    print("##")
else:
    print("###")
# prints #

if temp <= 40:
    print("#")
elif temp == 42:
    print("##")
else:
    print("###")
#prints #

if temp == 42:
    print("#")
elif temp <= 40:
    print("##")
else:
    print("###")

#prints ##