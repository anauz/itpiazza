pressure = 1
while pressure < 4:
    pressure += 2
    print("#", end="")
else:
    print("#")
