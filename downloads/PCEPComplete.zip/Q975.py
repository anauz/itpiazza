result = 0
for x in range(2, 4):
    for y in range(1, 3):
        if x > y:
            result += 2
        else:
            result -= 1
print(result)
