# Define the functions
def alpha(default=5):
    print(f"alpha called with default={default}")

def beta():
    print("beta called with no arguments")

def gamma(x, y):
    print(f"gamma called with x={x} and y={y}")

def delta(a, b, c=10):
    print(f"delta called with a={a}, b={b}, and c={c}")

# Test the functions
# This will work because alpha can be called with one argument or none (default value used)
alpha(3)  # Output: alpha called with default=3
alpha()   # Output: alpha called with default=5

# This will raise a TypeError because beta does not accept any arguments
try:
    beta(3)
except TypeError as e:
    print(f"Error: {e}")  # Output: Error: beta() takes 0 positional arguments but 1 was given

# This will raise a TypeError because gamma requires exactly two arguments
try:
    gamma(3)
except TypeError as e:
    print(f"Error: {e}")  # Output: Error: gamma() missing 1 required positional argument: 'y'

# This will work if called with at least two arguments, but raise an error if only one is provided
try:
    delta(3)
except TypeError as e:
    print(f"Error: {e}")  # Output: Error: delta() missing 1 required positional argument: 'b'
try:
    delta(3, 4)  # This will work
except TypeError as e:
    print(f"Error: {e}")  # Output: delta called with a=3, b=4, and c=10
