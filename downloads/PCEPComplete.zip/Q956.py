def calculate(x, y=5, z=10, multiply=False):
    if multiply:
        return x * y * z
    else:
        return x + y + z

print(calculate(2, z=3, y=4)[2])