items = [5, 3, 7, 8]

print(items[items[1]]) #prints 8

print (items[2:4]) #prints [7, 8]

#print(items[4]) #Raises an IndexError.

#print(items[items[2]]) #Raises an IndexError.