# Demonstrating tuple immutability
my_tuple = (1, 2, 3)
print("Original tuple:", my_tuple)

try:
    # Attempting to change an element in the tuple (this will raise an error)
    my_tuple[0] = 4
except TypeError as e:
    print("Error:", e)

# Demonstrating the index() method
element = 2
index = my_tuple.index(element)
print(f"The index of element {element} in the tuple is:", index)

# Demonstrating nested tuples
nested_tuple = (1, (2, 3), 4)
print("Nested tuple:", nested_tuple)
