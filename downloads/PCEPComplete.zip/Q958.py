# Define the functions
def alpha(count=50):
    print(f"alpha called with count={count}")

def beta(count):
    print(f"beta called with count={count}")

def delta():
    print("delta called with no arguments")

def gamma(count, rate=10):
    print(f"gamma called with count={count} and rate={rate}")

# Test the functions
# This will work because alpha can be called with one argument or none (default value used)
alpha(5)  # Output: alpha called with count=5
alpha()   # Output: alpha called with count=50

# This will work because beta requires exactly one argument
beta(5)   # Output: beta called with count=5

# This will raise a TypeError because delta does not accept any arguments
try:
    delta(5)  # This should raise an error
except TypeError as e:
    print(f"Error: {e}")  # Output: Error: delta() takes 0 positional arguments but 1 was given

# This will work because gamma can be called with one argument, using the default value for rate
gamma(5)  # Output: gamma called with count=5 and rate=10
gamma(5, 20)  # Output: gamma called with count=5 and rate=20
