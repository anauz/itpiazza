my_list = [1, 2, False]

print(len(my_list) == my_list[1]) #False

print(my_list.index(False) == 2) #True

print(2 not in my_list) #False

print(my_list[0] > my_list[2]) #True