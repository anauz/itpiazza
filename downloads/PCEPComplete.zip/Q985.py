def sum_numbers(n):
    if n <= 0:
        return 0
    return n + sum_numbers(n - 2)

print(sum_numbers(4))
