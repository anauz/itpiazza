try:
    print("Try block")
except ValueError:
    print("Caught an exception")
else:
    print("No exceptions raised")  # This line executes because no exceptions were raised

try:
    raise ValueError("An error occurred")
except (ValueError, TypeError):
    print("Caught an exception")

try:
    raise ValueError("An error occurred")
except ValueError:
    print("Caught an exception")
finally:
    print("This will always execute")

try:
    print("Before exception")
    raise ValueError("An error occurred")
    print("After exception")  # This line is never executed
except ValueError:
    print("Caught an exception")