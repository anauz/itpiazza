speed = 10
while speed > 0:
    speed -= 4
    print("#", end="")
else:
    print("#")
