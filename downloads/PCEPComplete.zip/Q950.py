values = (False, True, False, True)
selected = values[2:]
score = 0
for value in selected[::-1]:
    if not value:
        score += 2
print(score)