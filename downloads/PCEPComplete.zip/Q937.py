x = 3
x = x * 2
print(x)