balance = 10
for k in range(4):
    if k % 2 == 0:
        balance *= 2
    else:
        balance -= 3
print(balance)