def calculate(number):
    return number * 2

a = calculate(number = 3)
b = calculate(a)
print(b)
