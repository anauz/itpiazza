moons = 3 * 2 - 10 // 3 + 5 % 2
if moons == 3:
    print("A")
elif moons < 5:
    print("B")
else:
    print("C")