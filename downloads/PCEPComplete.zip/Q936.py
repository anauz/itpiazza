# Legal variable names
_validName = "This is a valid variable name."
Class = "This is also a valid variable name."
variable_1 = "This variable name includes an underscore and a number."
another_variable = "This variable name uses only letters and underscores."

# Print the values of legal variables
print(_validName)
print(Class)
print(variable_1)


# Illegal variable names
# The following lines are commented out because they will cause syntax errors if executed

# class = "This is not valid because 'class' is a reserved keyword."
# #hashtag = "This is not valid because variable names cannot start with a special character."
# 1st_place = "This is not valid because variable names cannot start with a digit."

# Uncommenting the following lines will raise a SyntaxError:
# print(class)
# print(#hashtag)
# print(1st_place)
