def modify(values):
    values[2] = 4
    return values[1]

numbers = [1 for i in range(4)]
modify(numbers)
print(numbers[2])
