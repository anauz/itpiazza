values = (False, True, True)
subset = values[1:]
score = 0
for value in subset[::-1]:
    if value:
        score += 1
print(score)