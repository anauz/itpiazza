original_list = [4, 5]
copied_list = original_list[:]
copied_list.insert(1, 6)
print(original_list[1])