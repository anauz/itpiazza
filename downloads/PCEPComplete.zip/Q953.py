try:
    value = int("XYZ")
except ValueError:
   print("Caught an error")
except:
   print("Oh no")