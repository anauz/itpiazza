charge = 1
while charge != 8:
    charge *= 2
    if charge == 4:
        continue
    print("!", end="")
else:
    print("!")