values = [4, 7, 1, 9]

print(values[values[2]]) #7

print(values[4:4]) #[]

#print(values[values[1]]) #IndexError:

#print(values[values[4]]) #IndexError:

