values = [1, "apple", 3.5, -2]

print(values[2] == 3.5) #True

print("banana" in values) #False

print(len(values) > 3) #True

print(values[-1] == 2) #False