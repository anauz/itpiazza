value = 5 % 3 - 1
if value < 0:
    print("#")
elif value > 1:
    print("##")
else:
    print("###")
#prints ###

value = 5 % 3 - 1
if value < 0:
    print("#")
elif value == 1:
    print("##")
else:
    print("###")
#prints ##

value = 5 % 3 - 1
if value == 1:
    print("#")
elif value < 0:
    print("##")
else:
    print("###")
#prints #


value = 5 % 3 - 1
if value >= 2:
    print("#")
elif value == 1:
    print("##")
else:
    print("###")
#prints ##