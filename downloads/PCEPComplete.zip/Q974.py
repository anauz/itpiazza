
score = 3
for k in range(3, 6):
    if k % 3 == 0:
        score += 2
    else:
        score -= 1
print(score)