def countdown(stop, start=5):
    print(start, end=' ')
    if start > stop:
        countdown(stop, start - 1)

countdown(2)