count = 0
for x in range(3):
    for y in range(3):
        if x == y:
            count += 2
        else:
            count += 1
print(count)
