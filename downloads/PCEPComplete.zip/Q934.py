# Original expression
expression = 2 - 3 * 2 ** 2

# Evaluated in steps
step1 = 2 ** 2  # Exponentiation: 4
step2 = 3 * step1  # Multiplication: 12
result = 2 - step2  # Subtraction: -10

print("Result of the expression 2 - 3 * 2 ** 2 is:", result)