import pandas as pd

# Example dataset
data = {
    'City': ['NYC', 'Los Angeles', 'Chicago', 'NYC', 'Boston', 'New York City', 'LA', 'SF', 'San Francisco']
}
df = pd.DataFrame(data)
print("Before", df, sep="\n")

# Mapping of abbreviations to full names
city_mapping = {
    'NYC': 'New York City',
    'LA': 'Los Angeles',
    'SF': 'San Francisco'
}

# Standardize the City column
df['City'] = df['City'].replace(city_mapping)

print("After", df, sep="\n")
