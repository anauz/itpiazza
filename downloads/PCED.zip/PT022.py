import pandas as pd
import numpy as np
from scipy import stats
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

np.random.seed(0)  # For reproducibility

# Sample data with non-linear relationship
data = {
    'X': np.random.rand(100),
    'Y': np.random.rand(100) ** 2 * 100  # Squaring to introduce non-linearity
}
df = pd.DataFrame(data)

# Linear Regression Model
X_train, X_test, Y_train, Y_test = train_test_split(df[['X']], df['Y'], test_size=0.2)
model = LinearRegression().fit(X_train, Y_train)

# Initial Predictions and Residual Analysis
initial_predictions = model.predict(X_test)
initial_residuals = Y_test - initial_predictions

# Check for normality of residuals
_, p_value_initial = stats.shapiro(initial_residuals)
print("P-value for Shapiro-Wilk Test:", p_value_initial)
p_value_initial_result = "Initial Model - P-value for Shapiro-Wilk Test: {}".format(p_value_initial)

# Applying Box-Cox transformation

# Adding a small constant to avoid zero or negative values
df['Y_transformed'], _ = stats.boxcox(df['Y'] + 1e-5)

# Rebuilding Linear Regression Model with Transformed Data
X_train, X_test, Y_train_transformed, Y_test_transformed = train_test_split(df[['X']], df['Y_transformed'], test_size=0.2)
model_transformed = LinearRegression().fit(X_train, Y_train_transformed)

# Predictions and Residual Analysis with Transformed Data
transformed_predictions = model_transformed.predict(X_test)
transformed_residuals = Y_test_transformed - transformed_predictions

# Check for normality of transformed residuals
_, p_value_transformed = stats.shapiro(transformed_residuals)
p_value_transformed_result = "Transformed Model - P-value for Shapiro-Wilk Test: {}".format(p_value_transformed)

transformed_residuals_description = transformed_residuals.describe()
print("P-value for Shapiro-Wilk Test after transformation", p_value_transformed_result)


p_value_initial_result, "transformation performed", p_value_transformed_result, transformed_residuals_description

# Box-Cox transformation also reduced model errors
from sklearn import metrics
#Initial Predictions
print("MAE: ", metrics.mean_absolute_error(Y_test, initial_predictions))
print("MSE: ", metrics.mean_squared_error(Y_test, initial_predictions))
print("RMSE: ", np.sqrt(metrics.mean_squared_error(Y_test, initial_predictions)))

#Transformed Predictions
print("MAE: ", metrics.mean_absolute_error(Y_test_transformed,transformed_predictions))
print("MSE: ", metrics.mean_squared_error(Y_test_transformed,transformed_predictions))
print("RMSE: ", np.sqrt(metrics.mean_squared_error(Y_test_transformed,transformed_predictions)))
