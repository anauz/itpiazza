import pandas as pd

# Assuming 'employees.csv' exists with a 'salary' column
df = pd.read_csv('employees.csv')
average_salary = df['salary'].mean()

print(f"Average Salary: {average_salary}")