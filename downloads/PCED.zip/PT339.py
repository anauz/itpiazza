temperatures = [72, 75, 78, 72, 70, 72, 76, 79]

print(sorted(temperatures)[len(temperatures) // 2]) # does not work for even-length lists

# print(median_temp = temperatures.median()) #returns an error

print(sorted(temperatures)[len(temperatures) // 2] if len(temperatures) % 2 == 1 else (sorted(temperatures)[len(temperatures) // 2 - 1] + sorted(temperatures)[len(temperatures) // 2]) / 2)

print(max(set(temperatures), key=temperatures.count)) #calculates mode

#the other way
import numpy as np

median_temp = np.median(temperatures)
print(median_temp)