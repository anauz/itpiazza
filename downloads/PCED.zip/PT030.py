import pandas as pd
import numpy as np

# Creating a sample DataFrame with a 'Price' column
df = pd.DataFrame({'Price': [200, 300, 400, 500, 600]})
print(df)

# Option a) Standardizing the 'Price' column
df_a = df.copy()
df_a['Price'] = (df_a['Price'] - df_a['Price'].mean()) / df_a['Price'].std()

print("option a:", df_a)

# Calculating the mean and standard deviation of the standardized 'Price' column
mean_price = df_a['Price'].mean()
std_dev_price = df_a['Price'].std()

# Displaying the mean and standard deviation
print("Mean: ", mean_price, "stdev:", std_dev_price)


# Option b) Normalizing by dividing by the maximum value
df_b = df.copy()
df_b['Price'] = df_b['Price'] / df_b['Price'].max()

print("option b:", df_b)
mean_price = df_b['Price'].mean()
std_dev_price = df_b['Price'].std()

# Displaying the mean and standard deviation
print("Mean: ", mean_price, "stdev:", std_dev_price)

# Option c) Applying min-max normalization
df_c = df.copy()
df_c['Price'] = (df_c['Price'] - df_c['Price'].min()) / (df_c['Price'].max() - df_c['Price'].min())

print("option c:", df_c)
mean_price = df_c['Price'].mean()
std_dev_price = df_c['Price'].std()

# Displaying the mean and standard deviation
print("Mean: ", mean_price, "stdev:", std_dev_price)

#option d)
df_d = df.copy()
#df_d['Price'] = df_d['Price'].apply(lambda x: (x - np.mean(x)) / np.std(x)) error

