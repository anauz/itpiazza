import pandas as pd

# Example DataFrame
data = {
    'CustomerID': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
    'Age': [25, 30, 35, 40, 45, 30, 25, 45, 32, 44, 35],
    'Purchases': [4, 6, 7, 2, 9, 9, 6, 3, 6, 8, 9]
}
customer_data = pd.DataFrame(data)

print(customer_data)

# Calculate average age of customers with more than 5 purchases
average_age = customer_data[customer_data['Purchases'] > 5]['Age'].mean()  # the correct option
print(f"Average Age: {average_age}")

print("option 4", customer_data.query('Purchases > 5').groupby('Age').mean(), sep="\n") #the incorrect option
#with groupby we got mean values of all columns, even for CustomerID which is incorrect


