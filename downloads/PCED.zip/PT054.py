import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Lasso
from sklearn.metrics import mean_squared_error

# Set random seed for reproducibility
np.random.seed(0)

# Generate a more complex synthetic dataset
np.random.seed(0)
X = np.random.rand(100, 10) * 100  # 10 features
y = 2 * X[:, 0] + 3 * X[:, 1] - 1.5 * X[:, 2] + np.random.randn(100) * 20  # Non-linear relationship

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Train linear regression model
lin_reg = LinearRegression()
lin_reg.fit(X_train, y_train)

# Predict on test set
y_pred_lin = lin_reg.predict(X_test)

# Calculate variance (mean squared error)
variance_lin_reg = mean_squared_error(y_test, y_pred_lin)
print(f"Variance of Linear Regression model: {variance_lin_reg}")
# Train Lasso regression model
lasso_reg = Lasso(alpha=1.0)
lasso_reg.fit(X_train, y_train)

# Predict on test set
y_pred_lasso = lasso_reg.predict(X_test)

# Calculate variance
variance_lasso_reg = mean_squared_error(y_test, y_pred_lasso)
print(f"Variance of Lasso Regression model: {variance_lasso_reg}")
