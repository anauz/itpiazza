import pandas as pd

# Assuming 'employees2.csv' has the required structure
# This line will efficiently load only the 'Department' and 'Salary' columns with 'EmpID' as the index

df = pd.read_csv('employees2.csv', usecols=['Department', 'Salary', 'EmpID'], index_col='EmpID')
print(df.head())
