import pandas as pd
import matplotlib.pyplot as plt
import random

# Sample data
data = {
    'Date': pd.date_range(start='2020-01-01', periods=365, freq='D'),
    'City_A': [22 + i % 10 + random.randint(1, 10) for i in range(365)],
    'City_B': [18 + i % 5 + random.randint(1, 10)for i in range(365)],
    'City_C': [20 + i % 7 + random.randint(1, 10)for i in range(365)]
}
df = pd.DataFrame(data)

# Plotting multiple line graphs
plt.plot(df['Date'], df['City_A'], label='City A')
plt.plot(df['Date'], df['City_B'], label='City B')
plt.plot(df['Date'], df['City_C'], label='City C')
plt.xlabel('Date')
plt.ylabel('Temperature')
plt.title('Daily Temperature Trends Across Cities')
plt.legend()
plt.show()