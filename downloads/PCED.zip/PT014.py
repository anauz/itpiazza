from bs4 import BeautifulSoup

html_doc = """
<div class="article">
  <h3>Article One</h3>
  <span>John Doe</span>
</div>
<div class="article">
  <h3>Article Two</h3>
  <span>Jane Doe</span>
</div>
"""

soup = BeautifulSoup(html_doc, 'html.parser')

for article in soup.select('.article'):
    title = article.h3.text
    author = article.span.text
    print(title, author)

