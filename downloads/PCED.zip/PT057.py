import matplotlib.pyplot as plt

# Sample data
countries = ['Country A', 'Country B', 'Country C', 'Country D', 'Country E']
sunshine_hours = [2500, 2000, 3000, 1000, 3500]
average_temp = [20, 15, 25, 10, 30]

# Creating a scatter plot with color coding
plt.scatter(sunshine_hours, average_temp, c=sunshine_hours, cmap='viridis')
plt.colorbar(label='Average Yearly Sunshine Hours')

# Labeling
plt.xlabel('Average Yearly Sunshine Hours')
plt.ylabel('Average Annual Temperature')
plt.title('Relationship Between Sunshine Hours and Temperature')

# Annotating each country next to its point
for i, country in enumerate(countries):
    plt.text(sunshine_hours[i], average_temp[i], ' ' + country, fontsize=9)

plt.show()

