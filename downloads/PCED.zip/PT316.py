fruit = "banana"
numbers1 = (8, 3, 9, 2)
numbers2 = (5, 7, 6, 1)
combined_numbers = numbers1 + numbers2
unique_set = set([ord(fruit[2]), combined_numbers[7]])

print("Third Character:", fruit[2]) #n
print("Eighth Number:", combined_numbers[7]) #1
print("Unique Set:", unique_set) #{1, 110}