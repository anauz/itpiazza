import matplotlib.pyplot as plt

a = [2, 4, 6, 8, 10]
b = [1, 3, 5, 7, 9]

plt.plot(a, b, color='green', linestyle='solid', marker='s',
         markerfacecolor='yellow', mec='blue', linewidth=1.5, alpha=0.9,
         label='Custom Plot')
plt.xlabel('A Axis')
plt.ylabel('B Axis')
plt.title('Example Plot')
plt.legend(loc='lower left')
plt.show()