import pandas as pd

# Sample DataFrame
df = pd.DataFrame({
    'Department': ['Sales', 'HR', 'IT', 'Sales', 'IT'],
    'Salary': [70000, 50000, 60000, 80000, 90000]
})
print(df)

# Working example of the correct code snippet
average_salary = df.groupby('Department')['Salary'].mean()
print(average_salary)

av_s1 = df.pivot_table(values='Salary', index='Department', aggfunc='mean')
print(av_s1)

#av_s2 = df['Salary'].groupby(df['Department']).average()
#print(av_s2)

av_s3 = df.groupby('Department').apply(lambda x: x['Salary'].mean())

print(av_s3)