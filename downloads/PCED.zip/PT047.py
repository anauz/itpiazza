import numpy as np

# Sample data
data = np.array([10, 12, 15, 100, 10, 13, 14, 15, 16, 20, 12, 13, 14])
print("Original data: ", data)
# Calculating mean and standard deviation
mean = np.mean(data)
print("Mean value is: ", mean)
std_dev = np.std(data)
print("Standard deviation is:", std_dev)

print("Median of the array is:", np.median(data))

# Replacing outliers with median
print("Data to be recplaced: ")
print(data[(data < mean - 2 * std_dev) | (data > mean + 2 * std_dev)] )
data[(data < mean - 2 * std_dev) | (data > mean + 2 * std_dev)] = np.median(data)
print("Modified data:", data)
