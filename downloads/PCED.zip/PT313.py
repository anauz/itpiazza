def check_booking_info(name, contact, email):
    if not name.replace(' ', '').isalpha():
        return "Name must contain only letters and spaces."
    if not contact.isdigit() or len(contact) != 10:
        return "Contact number must be a 10-digit number."
    if "@" not in email or "." not in email:
        return "Email must contain an '@' and a '.' character."
    return "All inputs are valid."

result = check_booking_info("John Doe", "1234567890", "john@example.com")

print(result)

result2 = check_booking_info("John Doe", "1234567890", "john@examplecom")

print(result2)