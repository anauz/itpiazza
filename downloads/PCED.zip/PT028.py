import pandas as pd
import numpy as np

# Creating a DataFrame with a column 'C' having some NaN values
df = pd.DataFrame({'C': [1, 2, np.nan, 4, np.nan, 6]})
print(df)

# Option a) Filling NaN with the mean and modifying the DataFrame in place
df_a = df.copy()
df_a['C'].fillna(df_a['C'].mean(), inplace=True)

# Option b) Replacing NaN with the mean without modifying the DataFrame in place
df_b = df.copy()
df_b['C'].replace(np.nan, df_b['C'].mean())

# Option c) Dropping rows with NaN
df_c = df.copy()
df_c.dropna(inplace=True)

# Option d) Counting the number of NaN values in the column
nan_count = df['C'].isnull().sum()

# Displaying the results
print("DataFrame with NaN filled by mean (Option a):")
print(df_a)
print("\nDataFrame with NaN replaced by mean (Option b):")
print(df_b)
print("\nDataFrame after dropping NaN rows (Option c):")
print(df_c)
print("\nCount of NaN values in the column (Option d):", nan_count)
