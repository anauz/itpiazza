import requests

# URL of the web service
url = "https://example.com/api/data"

# Data to be sent to the server
data = {
    "name": "John Doe",
    "email": "johndoe@example.com"
}

# Sending a POST request to the server
response = requests.post(url, data=data)

# Checking the response
if response.status_code == 200:
    print("Data sent successfully.")
else:
    print("Failed to send data.")