import numpy as np
from scipy import stats

# Given data
sales_data = [150, 200, 150, 250, 150, 300, 150]

# Calculating mean
mean = np.mean(sales_data)

# Calculating median
median = np.median(sales_data)

# Calculating mode
mode = stats.mode(sales_data)[0]

# Calculating range
range_value = np.max(sales_data) - np.min(sales_data)

# Printing the results
print(f"Mean: {mean}")
print(f"Median: {median}")
print(f"Mode: {mode}")
print(f"Range: {range_value}")


# Sorting the data
sales_data_sorted = sorted(sales_data)

# Calculating Q1, Q2 (Median), Q3
Q1 = np.percentile(sales_data_sorted, 25)
Q2 = np.median(sales_data_sorted)
Q3 = np.percentile(sales_data_sorted, 75)

# Calculating IQR
IQR = Q3 - Q1

# Printing the results
print(f"Q1 (25th percentile): {Q1}")
print(f"Q2 (Median): {Q2}")
print(f"Q3 (75th percentile): {Q3}")
print(f"IQR (Interquartile Range): {IQR}")

from scipy.stats import iqr

# Calculate IQR
iqr_value = iqr(sales_data)

print(f"IQR: {iqr_value}")
