import re

def validate_phone_number(number):
    pattern = re.compile(r"^\+?[1-9]\d{1,14}$")  # Simple E.164 format validation
    return pattern.match(number)

# Example usage
phone_number = "+1234567890"
if validate_phone_number(phone_number):
    print("Valid phone number.")
else:
    print("Invalid phone number.")
