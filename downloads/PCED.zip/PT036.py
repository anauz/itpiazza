import scipy.stats as stats

# Hypothetical processing times for the techniques
times_X = [1.2, 1.0, 1.1]
times_Y = [1.8, 1.7, 1.9]
times_Z = [1.4, 1.3, 1.5]

# Performing an ANOVA test
f_value, p_value = stats.f_oneway(times_X, times_Y, times_Z)
print("P-value:", p_value)

# Interpreting the p-value
if p_value < 0.05:
    print("At least one technique is significantly more efficient than the others at the 0.05 level.")
else:
    print("No significant difference in efficiency at the 0.05 level.")
