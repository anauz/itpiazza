
def validate_weather_data(records):
    for record in records:
        if not isinstance(record['RecordID'], int) or not isinstance(record['Temperature'], (int, float)):
            return False
        if record['Temperature'] < -50 or record['Temperature'] > 50:
            return False
        if record['Precipitation'] < 0:
            return False
    return True

records = [
    {'RecordID': 101, 'Date': '2023-01-01', 'Temperature': 25.0, 'Precipitation': 5.0},
    {'RecordID': 102, 'Date': '2023-01-02', 'Temperature': -55.0, 'Precipitation': 2.0},
    # ... more records
]

validation_result = validate_weather_data(records)