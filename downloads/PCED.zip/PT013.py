import psycopg2
import pandas as pd

def read_postgres_to_df(database_url, query):
    con = psycopg2.connect(database_url)
    df = pd.read_sql_query(query, con)
    con.close()
    return df

# Assuming a PostgreSQL database URL and a valid SQL query
database_url = 'postgresql://username:password@localhost:5432/mydatabase'
query = 'SELECT * FROM my_table'

# Reading data into DataFrame
dataframe = read_postgres_to_df(database_url, query)
print(dataframe)
