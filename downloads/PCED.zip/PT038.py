import urllib.request

# Sample URL for demonstration
url = 'http://example.com'

# Sending a request and capturing the response
response = urllib.request.urlopen(url)

# Checking the HTTP response code
if response.getcode() == 200:
    print("Request successful, data retrieved.")
else:
    print("Request failed, response code:", response.getcode())
