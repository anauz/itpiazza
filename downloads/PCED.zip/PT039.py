# Poor practice - cryptic variable names
def calc(a, b):
    return a * b

result = calc(5, 10)
print("Result:", result)  # Output is not clear

# Good practice - descriptive variable names
def multiply_numbers(number1, number2):
    return number1 * number2

product = multiply_numbers(5, 10)
print("Product:", product)  # Output is clear and understandable