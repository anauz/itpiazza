import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

# Expanded synthetic dataset
# Further expanded synthetic dataset with more variations
data = {
    'review': [
        'Loved the product', 'Hated the product', 'Best purchase ever',
        'Worst purchase ever', 'Will buy again', 'Never buying this',
        'Very satisfied', 'So disappointed', 'Happy with my purchase', 'Regret this purchase',
        'Really loved the product', 'Totally hated the product', 'An amazing purchase',
        'A terrible purchase', 'Definitely will buy again', 'Not buying this again',
        'Quite satisfied', 'Extremely disappointed', 'Content with my purchase', 'Deeply regret this purchase',
        'Absolutely love this product', 'Absolutely hate this product', 'Incredible purchase',
        'Disastrous purchase', 'Certainly will buy again', 'Certainly won’t buy this again',
        'Totally satisfied', 'Completely disappointed', 'Thrilled with my purchase', 'Very unhappy with this purchase',
        'Product is fantastic', 'Product is terrible', 'Highly recommend this',
        'Would not recommend this', 'Satisfied customer here', 'Dissatisfied customer here',
        'Worth every penny', 'Not worth the money', 'Exceeds my expectations', 'Falls short of expectations'
    ] ,  # Repeat the reviews to increase the dataset size
    'sentiment': [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0,
                  1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0]
}

df = pd.DataFrame(data)


# Splitting dataset
X_train, X_test, y_train, y_test = train_test_split(df['review'], df['sentiment'], test_size=0.2, random_state=0)

# Vectorization
vectorizer = CountVectorizer()
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# Training the Naive Bayes Classifier
nb_classifier = MultinomialNB()
nb_classifier.fit(X_train_vec, y_train)

# Predicting and evaluating
y_pred = nb_classifier.predict(X_test_vec)
accuracy = accuracy_score(y_test, y_pred)
print(f"Model Accuracy: {accuracy}")
