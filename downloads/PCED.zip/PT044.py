import pandas as pd

# Sample CSV content as a string for demonstration
csv_data = '''Name,Department,Salary
John,Sales,70000
Jane,Marketing,75000
Mark,IT,80000'''

# Writing the CSV data to a file for loading into DataFrame
with open('employees.csv', 'w') as file:
    file.write(csv_data)

# Loading CSV into DataFrame and calculating average salary for IT Department
df = pd.read_csv('employees.csv')
it_department = df[df['Department'] == 'IT']
avg_salary = it_department['Salary'].mean()
print(avg_salary)