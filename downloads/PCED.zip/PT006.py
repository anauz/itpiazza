import pandas as pd

# Sample data for demonstration
df1 = pd.DataFrame({'order_id': [1, 2], 'amount': [100, 200]})
df2 = pd.DataFrame({'order_id': [2, 3], 'amount': [300, 400]})

# Combining and aggregating the data
combined_df = pd.concat([df1, df2]).groupby('order_id').sum().reset_index()

print(combined_df)

