import pandas as pd

df = pd.DataFrame({'Name': ['Alice', 'Bob', 'Charlie']})

# Adding the NameCount column
df['NameCount'] = df['Name'].str.len()
#df['NameCount'] = len(df['Name'])
#df['NameCount'] = df.apply(len, axis=1)
#df['NameCount'] = df['Name'].length()


print(df)