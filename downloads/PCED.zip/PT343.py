import matplotlib.pyplot as plt
import numpy as np

# Sample data
months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
men_wear = [80, 82, 81, 83, 85, 84, 86, 87, 85, 88, 87, 89]
women_wear = [78, 79, 77, 80, 81, 80, 83, 84, 82, 85, 84, 86]
kids_wear = [75, 77, 76, 78, 79, 78, 80, 81, 80, 82, 81, 83]
categories = ['Men\'s Wear', 'Women\'s Wear', 'Kids\' Wear']
overall_satisfaction = [85, 83, 81]

# Data for the pie chart (Objective 3)
satisfaction_distribution = [50, 30, 20]

# Line Graph for Objective 1
plt.figure(figsize=(12, 6))
plt.plot(months, men_wear, 'b-o', label='Men\'s Wear')
plt.plot(months, women_wear, 'g-s', label='Women\'s Wear')
plt.plot(months, kids_wear, 'r-^', label='Kids\' Wear')
plt.xlabel('Month')
plt.ylabel('Customer Satisfaction Score')
plt.title('Monthly Customer Satisfaction Scores by Product Category')
plt.legend()
plt.grid(True)
plt.show()

# Bar Chart for Objective 2
plt.figure(figsize=(8, 6))
plt.bar(categories, overall_satisfaction, color=['blue', 'green', 'red'])
plt.xlabel('Product Category')
plt.ylabel('Overall Customer Satisfaction Score')
plt.title('Overall Customer Satisfaction Comparison')
plt.show()

# Pie Chart for Objective 3
plt.figure(figsize=(8, 6))
plt.pie(satisfaction_distribution, labels=categories, autopct='%1.1f%%', startangle=140)
plt.title('Distribution of Most Satisfied Customers by Product Category')
plt.show()
