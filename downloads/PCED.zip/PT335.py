import pandas as pd
import numpy as np

data = pd.DataFrame([[np.nan, 2, 3],
                     [5, np.nan, 7],
                     [8, 9, np.nan]],
                     columns=list('ABC'))

# Correct way to use fillna(0)
filled_data = data.fillna(0)
print(filled_data)