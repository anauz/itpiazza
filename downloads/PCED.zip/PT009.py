import pandas as pd
from datetime import datetime

# Sample data
data = {
    'transaction_time': ['2023-01-03', '2023-01-01', '2023-01-02'],
    'amount': [100, 50, 75]
}
df = pd.DataFrame(data)
df['transaction_time'] = pd.to_datetime(df['transaction_time'])

# Sorting the DataFrame
sorted_df = df.sort_values(by='transaction_time')

print(sorted_df)
