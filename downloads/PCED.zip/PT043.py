import requests
import json

# If it does not work replace 'YOUR_API_KEY' with your actual Alpha Vantage API key
api_key = 'YOUR_API_KEY'
symbol = 'IBM'  # Example stock symbol

# Alpha Vantage API endpoint for real-time stock market data
url = f'https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol={symbol}&interval=5min&apikey={api_key}'

# Sending a GET request to the API
response = requests.get(url)

# Checking if the request was successful
if response.status_code == 200:
    # Parsing the JSON data
    data = response.json()
    print(json.dumps(data, indent=4))  # Printing the data in a formatted way
else:
    print("Failed to fetch data. Status code:", response.status_code)
