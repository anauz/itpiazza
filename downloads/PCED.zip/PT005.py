import pandas as pd
from datetime import datetime

# Sample data with inconsistent date formats
data = {'date': ['2023-01-10', '01/11/2023', '2023.12.01', '2023/01/13']}
df = pd.DataFrame(data)

# Function to standardize date format
def standardize_date(date_str):
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%Y.%m.%d', '%Y/%m/%d'):
        try:
            return datetime.strptime(date_str, fmt).strftime('%Y-%m-%d')
        except ValueError:
            pass
    return None  # or return a default value, or raise an exception

# Applying the function to the DataFrame
df['standardized_date'] = df['date'].apply(standardize_date)

print(df)
