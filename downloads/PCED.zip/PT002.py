import pandas as pd

# Creating a sample DataFrame
sales = pd.DataFrame({
    'Month': ['January', 'January', 'February', 'February'],
    'Product': ['A', 'B', 'A', 'B'],
    'Quantity': [10, 15, 20, 25],
    'Revenue': [1000, 1500, 2000, 2500]
})

# Pivoting the DataFrame
pivoted_sales = sales.pivot(index='Month', columns='Product', values='Revenue')

print(pivoted_sales)


# Setting 'Month' and 'Product' as index and then unstacking 'Product'
unstacked_sales = sales.set_index(['Month', 'Product']).unstack(level='Product')['Revenue']

print(unstacked_sales)