import cProfile

# Example function to simulate data processing
def process_data():
    total = 0
    for i in range(1000000):
        total += i
    return total

# Profiling the process_data function
cProfile.run('process_data()')
