import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.datasets import make_regression
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

# Create a synthetic dataset with a moderate number of features
np.random.seed(42)
X, y = make_regression(n_samples=100, n_features=20, noise=10, random_state=42)

# Add polynomial features to increase model complexity
poly = PolynomialFeatures(degree=2, include_bias=False)
X_poly = poly.fit_transform(X)

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_poly, y, test_size=0.3, random_state=42)

# Scale the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train a Linear Regression model
linear_model = LinearRegression()
linear_model.fit(X_train_scaled, y_train)

# Train a Ridge Regression model with a balanced alpha
ridge_model = Ridge(alpha=0.5)
ridge_model.fit(X_train_scaled, y_train)

# Calculate mean squared error for both models
linear_train_error = mean_squared_error(y_train, linear_model.predict(X_train_scaled))
linear_test_error = mean_squared_error(y_test, linear_model.predict(X_test_scaled))
ridge_train_error = mean_squared_error(y_train, ridge_model.predict(X_train_scaled))
ridge_test_error = mean_squared_error(y_test, ridge_model.predict(X_test_scaled))

print(f"Linear Regression - Training Error: {linear_train_error}, Test Error: {linear_test_error}")
print(f"Ridge Regression - Training Error: {ridge_train_error}, Test Error: {ridge_test_error}")
