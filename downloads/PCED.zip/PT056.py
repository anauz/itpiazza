import pandas as pd
from scipy.stats import chi2_contingency

# Sample data
data = {'Education Level': ['High School', 'Bachelor', 'Master', 'High School', 'Bachelor'],
        'Job Satisfaction': ['Satisfied', 'Dissatisfied', 'Satisfied', 'Dissatisfied', 'Satisfied']}
df = pd.DataFrame(data)

# Creating a contingency table
contingency_table = pd.crosstab(df['Education Level'], df['Job Satisfaction'])

# Performing the Chi-Square Test of Independence
chi2, p, dof, expected = chi2_contingency(contingency_table)

print("Chi-Square Statistic:", chi2)
print("P-value:", p)

# Interpretation
if p < 0.05:
    print("There is a significant association between Education Level and Job Satisfaction.")
else:
    print("There is no significant association between Education Level and Job Satisfaction.")