import pandas as pd

# Creating two sample DataFrames
df1 = pd.DataFrame({'ID': [1, 2, 3], 'Name': ['Alice', 'Bob', 'Charlie']})
df2 = pd.DataFrame({'ID': [1, 2, 4], 'Age': [25, 30, 35]})

# Merging the DataFrames on the 'ID' column
merged_df = df1.merge(df2, on='ID')
print("Merged:\n", merged_df)

# Output:
# Merged:
#    ID   Name  Age
# 0   1  Alice   25
# 1   2    Bob   30

concatenated_df = pd.concat([df1, df2], axis=0)
print("\nConcatenated:\n", concatenated_df)

# Output:
# Concatenated:
#    ID     Name   Age
# 0   1    Alice   NaN
# 1   2      Bob   NaN
# 2   3  Charlie   NaN
# 0   1      NaN  25.0
# 1   2      NaN  30.0
# 2   4      NaN  35.0

# Joining the DataFrames using join (limited because it joins on indices by default)
# Setting the index to 'ID' for this purpose
df1_join = df1.set_index('ID')
df2_join = df2.set_index('ID')
joined_df = df1_join.join(df2_join)

print("\nJoined:\n", joined_df)

# Output:
# Joined:
#     Name  Age
# ID
# 1  Alice   25
# 2    Bob   30
# 3  Charlie NaN