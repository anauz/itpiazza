import pandas as pd

# Original DataFrame
data = {'Product': ['Book', 'Pen', 'Notebook'],
        'Stock': [100, 200, 150],
        'Price': [10, 2, 5]}

df = pd.DataFrame(data)

# Creating a new DataFrame with only 'Product' and 'Price' columns
df_product_price = df[['Product', 'Price']]

# Displaying the new DataFrame
print(df_product_price)

#print(df.loc[:, 'Product', 'Price']) #returns an error

#print(df.iloc[:, ['Product', 'Price']]) #returns an error

#print(df.loc[df['Product'], df['Price']]) #returns an error