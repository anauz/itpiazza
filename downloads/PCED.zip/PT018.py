import pandas as pd

# Sample data with mixed data types in 'Age' column
data = {
    'Customer_ID': [1, 2, 3],
    'Name': ['Alice', 'Bob', 'Charlie'],
    'Age': [30, '32', 28]
}
df = pd.DataFrame(data)

# Checking the data types
print(df.dtypes)