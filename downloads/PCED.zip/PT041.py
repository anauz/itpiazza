from sklearn.preprocessing import MinMaxScaler
import pandas as pd

# Example dataset
data = {
    'Variable1': [100, 200, 300, 350],
    'Variable2': [10, 20, 30, 40]
}
df = pd.DataFrame(data)
print(df)

# Applying Min-Max scaling
scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(df)

# Creating a DataFrame from scaled data
scaled_df = pd.DataFrame(scaled_data, columns=['Variable1', 'Variable2'])
print(scaled_df)