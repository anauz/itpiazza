from sklearn.tree import DecisionTreeClassifier
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load a sample dataset
data = load_breast_cancer()
X, y = data.data, data.target

# Splitting the dataset into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Creating and training the Decision Tree model
clf = DecisionTreeClassifier(max_depth=2)
clf.fit(X_train, y_train)

# Evaluating the model
train_accuracy = accuracy_score(y_train, clf.predict(X_train))
test_accuracy = accuracy_score(y_test, clf.predict(X_test))

print(f"Training Accuracy: {train_accuracy}, Test Accuracy: {test_accuracy}")

# Creating and training the Decision Tree model with increased depth
clf = DecisionTreeClassifier(max_depth=6)  # Increase the depth here
clf.fit(X_train, y_train)

# Evaluating the model
train_accuracy = accuracy_score(y_train, clf.predict(X_train))
test_accuracy = accuracy_score(y_test, clf.predict(X_test))

print(f"Training Accuracy: {train_accuracy}, Test Accuracy: {test_accuracy}")