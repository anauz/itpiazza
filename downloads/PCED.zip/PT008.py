import pandas as pd

# Sample sales data
data = {
    'store_id': [101, 102, None, 104],
    'sales_amount': [250.75, -150.00, 300.50, 0.00],
    'date': ['2023-01-15', '2023-01-16', 'not a date', '2023-01-18']
}

df = pd.DataFrame(data)

# User-defined validation function
def validate_sales_data(row):
    # Check for valid store ID
    if row['store_id'] is None:
        return False
    # Ensure sales amount is positive
    if row['sales_amount'] < 0:
        return False
    # Validate date format
    try:
        pd.to_datetime(row['date'])
    except ValueError:
        return False
    return True

# Apply validation
df['is_valid'] = df.apply(validate_sales_data, axis=1)

print(df)
