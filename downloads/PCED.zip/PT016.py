import pandas as pd
import matplotlib.pyplot as plt

# Sample data
data = {
    'Month': pd.date_range(start='2020-01-01', periods=12, freq='M'),
    'ProductA': [10, 30, 20, 70, 50, 60, 110, 40, 80, 120, 90, 100],
    'ProductB': [35, 25, 65, 45, 15, 85, 75, 55, 95, 105, 115, 125]
}
df = pd.DataFrame(data)

# Plotting the data
plt.plot(df['Month'], df['ProductA'], label='Product A')
plt.plot(df['Month'], df['ProductB'], label='Product B')
plt.xlabel('Month')
plt.ylabel('Sales')
plt.title('Monthly Sales Trends')
plt.legend()
plt.show()

# Combined Bar and Line Chart
fig, ax1 = plt.subplots()

# Bar chart for ProductA
ax1.bar(df['Month'], df['ProductA'], width=15, label='Product A Sales', color='blue', alpha=0.6)

# Line chart for ProductB on the same x-axis
ax2 = ax1.twinx()
ax2.plot(df['Month'], df['ProductB'], label='Product B Sales', color='red', marker='o')

# Setting labels and title
ax1.set_xlabel('Month')
ax1.set_ylabel('Product A Sales', color='blue')
ax2.set_ylabel('Product B Sales', color='red')
plt.title('Monthly Sales Trends for Products A and B')

# Adding legends
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')

# Display the plot
plt.show()
