import pandas as pd

# Example DataFrame
data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'Alice'],
    'Email': ['alice@example.com', 'bob@example.com', 'charlie@example.com', 'alice@example.com'],
    'Purchase': [250, 150, 300, 200]
}

customers = pd.DataFrame(data)
print("Original data: ", customers, sep="\n")

# Remove rows with duplicate email addresses
cleaned_customers = customers.drop_duplicates(subset='Email', keep='first')
print("Correctly cleaned data: ", cleaned_customers, sep="\n")

cleaned_customers2 = customers.drop_duplicates(subset='Email', keep=False)
print("Removed all duplicates in data: ", cleaned_customers2, sep="\n")

cleaned_customers3 = customers['Email'].drop_duplicates(keep='first')
print("Removed duplicates from the email column: ", cleaned_customers3, sep="\n")