def calculate_volume(length, width, height):
    return length * width * height

# Dimensions of the rectangular prism
length = 10
width = 5
height = 2

# Calling the function using a mix of positional and keyword arguments
volume = calculate_volume(length, width=width, height=height)

print("Volume of the rectangular prism:", volume)
