daily_hours = [8, 9, 7, 5, 6, 8, 10]
total_hours = 0
overtime = None

for hours in daily_hours:
    total_hours += hours

if total_hours > 40:
    overtime = True
else:
    overtime = False

print("Total Hours:", total_hours) #53
print("Overtime Achieved:", overtime) #True
