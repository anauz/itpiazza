import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Creating the dataset
data = {'Feature1': [10, 20, 30, 40, 50],
        'Feature2': [15, 25, 5, 35, 45],
        'Sales': [100, 200, 150, 250, 300]}
df = pd.DataFrame(data)

# Separating features and the continuous output
X = df[['Feature1', 'Feature2']]
y = df['Sales']

# Splitting the dataset into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scaling the continuous output variable 'Sales' if regularization techniques will be used
scaler_y = StandardScaler()
y_train_scaled = scaler_y.fit_transform(y_train.values.reshape(-1, 1)).flatten()

# Training a Linear Regression model
model = LinearRegression()
model.fit(X_train, y_train_scaled)

# Predicting 'Sales', reversing scaling for interpretation
predictions_scaled = model.predict(X_test)
predictions = scaler_y.inverse_transform(predictions_scaled.reshape(-1, 1)).flatten()
print("Predictions:", predictions)