import pandas as pd

employee_data = {'Name': ['Alice', 'Bob', 'Clara', 'David'],
                 'Years_of_Experience': [2, 7, 4, 10],
                 'Department': ['HR', 'Engineering', 'Marketing', 'Finance']}

employee_df = pd.DataFrame(employee_data)

# Correct way to retrieve the first row as a Pandas Series
first_employee = employee_df.iloc[0]
print(first_employee)
