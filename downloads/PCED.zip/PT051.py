import pandas as pd

# Example DataFrame
data = {
    'Year': [2020, 2021, 2020, 2021],
    'Department': ['Finance', 'Finance', 'HR', 'HR'],
    'Amount': [1000, 1500, 800, 900]
}
expenditure = pd.DataFrame(data)

# Calculate average annual expenditure for each department
average_expenditure = expenditure.groupby('Department')['Amount'].mean()
print(average_expenditure)
