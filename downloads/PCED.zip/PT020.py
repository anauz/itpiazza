from sklearn.datasets import load_digits
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

# Loading a sample high-dimensional dataset
digits = load_digits()
X, y = digits.data, digits.target

# Applying t-SNE for dimensionality reduction
tsne = TSNE(n_components=2, random_state=42)
X_reduced = tsne.fit_transform(X)

# Plotting the results
plt.scatter(X_reduced[:, 0], X_reduced[:, 1], c=y, cmap='viridis', s=50, alpha=0.6)
plt.colorbar()
plt.title("t-SNE visualization of digit images")
plt.show()