borrowing_counts = [5, 15, 8, 20, 12, 25]
popular_books = [count for count in borrowing_counts if count > 10]

print(popular_books)