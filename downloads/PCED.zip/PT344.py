import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# Example data creation
data = pd.DataFrame({
    'Weight': [120, 150, 80, 200, 180, 100, 140, 160, 130, 170],
    'Sweetness': [5, 7, 6, 8, 7, 6, 5, 9, 8, 6],
    'Color': ['Red', 'Green', 'Red', 'Yellow', 'Green', 'Yellow', 'Red', 'Green', 'Yellow', 'Red']
})

# Creating the box plot
sns.boxplot(data=data, x='Color', y='Sweetness')
plt.xlabel('Fruit Color')
plt.ylabel('Sweetness')
plt.title('Distribution of Sweetness by Fruit Color')
plt.show()
