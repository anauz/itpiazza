import pandas as pd

# Sample data
data = {
    'date': pd.date_range(start='2023-01-01', end='2023-03-31', freq='D'),
    'amount': [50] * 90
}
df = pd.DataFrame(data)

# Grouping by month and summing amounts
monthly_totals = df.groupby(df['date'].dt.to_period('M')).agg({'amount': 'sum'})

print(monthly_totals)
