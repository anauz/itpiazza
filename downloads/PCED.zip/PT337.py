import numpy as np

mat1 = np.array([[1, 2, 3],
                 [4, 5, 6],
                 [7, 8, 9],
                 [10, 11, 12]])

mat2 = np.array([[13, 14, 15, 16],
                 [17, 18, 19, 20],
                 [21, 22, 23, 24]])

# Correct way to perform matrix multiplication
result = np.dot(mat1, mat2)
print(result)
