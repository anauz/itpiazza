from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import accuracy_score

# Generating a synthetic dataset
X, y = make_classification(n_samples=1000, n_features=20, random_state=42)

# Splitting the dataset into training and tests sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Training a Decision Tree Classifier
dt_model = DecisionTreeClassifier(random_state=42)
dt_model.fit(X_train, y_train)

# Evaluating the Decision Tree model on both training and test data
dt_train_accuracy = accuracy_score(y_train, dt_model.predict(X_train))
dt_test_accuracy = accuracy_score(y_test, dt_model.predict(X_test))
print(f"Decision Tree - Training Accuracy: {dt_train_accuracy}, Accuracy on test dataset: {dt_test_accuracy}")

# Training a Gradient Boosting Classifier
gb_model = GradientBoostingClassifier(random_state=42)
gb_model.fit(X_train, y_train)

# Evaluating the Gradient Boosting model on both training and test data
gb_train_accuracy = accuracy_score(y_train, gb_model.predict(X_train))
gb_test_accuracy = accuracy_score(y_test, gb_model.predict(X_test))
print(f"Gradient Boosting - Training Accuracy: {gb_train_accuracy}, Accuracy on test dataset: {gb_test_accuracy}")
