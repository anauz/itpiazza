value = 1
while value < 8:
    value += 2
    if value >= 6:
        continue
    print('A', end='')
else:
    print('B')