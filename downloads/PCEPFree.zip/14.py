count = 0
for i in range(3, 6):
    for j in range(1, 4):
        if i % j == 2:
            if i - j == 2:
                count += 1
                break
print(count)
