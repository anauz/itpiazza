the_list = [False, 2.718, -5, 'hello']

# Evaluations
print(2.718 in the_list[1:3])  # Output: True
print(the_list.index(the_list[2]) == 1)  # Output: False
print(the_list.index('hello')  in the_list)  # Output: False
print(len(the_list[1:4]) == 3)  # Output: True
