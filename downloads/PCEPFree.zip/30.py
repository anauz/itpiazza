
try:
  x = input("Enter the first value: ")
  #x="Procoding"
  a = len(x)
  y = input("Enter the second value: ")
  #y="0"
  b = len(y) * 2
  print(a/b)
except ZeroDivisionError:
  print("You can't divide by zero!")
except ValueError:
  print("Wrong value error.")
except:
  print("Some other error.")