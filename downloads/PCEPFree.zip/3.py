print(4 % 2) #0
print(5 // 3) #1
print(7 % 3) #1
print(9 // 3) #3
print(6 % 3) #0