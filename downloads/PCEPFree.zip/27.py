# Demonstrating *args
def variable_args(*args):
    for arg in args:
        print(arg)

variable_args(1, 2, 3)  # Output: 1 2 3

# Demonstrating nested function
def outer_function():
    def inner_function():
        return "Hello from the inner function!"
    return inner_function()

print(outer_function())  # Output: Hello from the inner function!

# Demonstrating global keyword
x = 5

def modify_global():
    global x
    x = 10

modify_global()
print(x)  # Output: 10

# Demonstrating multiple return values
def multiple_returns():
    return 1, 2, 3

a, b, c = multiple_returns()
print(a, b, c)  # Output: 1 2 3
