try:
    value = 50 / 0
    print("All good")
except:
    print("It's caught!")