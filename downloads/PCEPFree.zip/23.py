

def process_file(file_path):
    file = open(file_path, 'r')
    try:
        data = file.read()
        print(data)
    finally:
        file.close()
        print("File has been closed")

# Simulate using the function with a file path
# Note: Replace 'example.txt' with a valid file path to test this
process_file('example.txt')

try:
    result = "string" + 10  # This raises a TypeError
except TypeError as e:
    print("Caught a TypeError:", e)

# Demonstrating program termination due to unhandled exception
print("This will be printed")
try:
    print(10 / 0)  # This raises a ZeroDivisionError
except ValueError as e:
    print("Caught a ValueError")

print("This will not be printed because the exception is not caught")