r = input()
s = input()
print(r * int(s))
