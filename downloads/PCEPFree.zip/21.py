

numbers = [1, 2, 7, 3, 4, 5, 6]
num = x[2: ]
print(y)
