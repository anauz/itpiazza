
tup = (42, ) + (42, ) + (13,)

tup = tup + tup

print(len(tup))
