

def f(x):
  if x % 2 == 0:
    return 1
  else:
    return

print(f(f(2)) + 11)