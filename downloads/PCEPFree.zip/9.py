speed = 5
while speed > 0:
    speed -= 2
    print("!", end="")
else:
    print("!")