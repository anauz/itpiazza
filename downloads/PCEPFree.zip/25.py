def subtract_and_store(value):
    return store - value

store = 10
store = subtract_and_store(3)
store = subtract_and_store(4)
print(store)
