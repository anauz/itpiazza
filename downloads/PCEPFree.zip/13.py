star = 5 + 3 * 2 - 8 // 4
if star < 5 :
    print("A")
elif star > 10 :
    print("B")
elif star == 9 :
    print("C")
else :
    print("D")
