numbers = [4, 2.5, 5, 0.5]

# Valid expressions
print(numbers[int(numbers[1])]) # Output: 5
print(numbers[int(numbers[3])])  # Output: 4

# Expressions that raise exceptions
try:
    print(numbers[int(numbers[0])])  # Raises IndexError
except IndexError as e:
    print("Error:", e)

try:
    print(numbers[int(numbers[2])])  # Raises IndexError
except IndexError as e:
    print("Error:", e)
