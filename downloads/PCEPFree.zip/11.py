for value in range(-12, -5, 2):
    print(value)