# Initial fruit_prices dictionary
fruit_prices = {
    'Apple': 1.49,
    'Banana': 0.99,
    'Cherry': 2.49
}

# Adding "Mango" at $2.99 to the dictionary
fruit_prices['Mango'] = 2.99

# Print the updated dictionary to verify the addition
print(fruit_prices)
