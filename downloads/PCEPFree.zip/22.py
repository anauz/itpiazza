numbers = [5, 10]
subset = numbers[1:]
subset.append(3)
print(numbers[-1] + subset[-1])