temp = 5
for j in range(-2, 2):
    if j % 3 == 0:
        temp += 3
    else:
        temp -= 1
print(temp)