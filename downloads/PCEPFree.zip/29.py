def modify_list(lst):
    lst.append(5)
    lst = [1, 2, 3]
    return lst

numbers = [0 for _ in range(4)]
new_numbers = modify_list(numbers)
print(numbers[1])
