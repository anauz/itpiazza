
x = "DataScience" "4U"
print(x)

