# Creating a tuple with elements of different types
my_tuple = (1, 'a', 3.14)

# Demonstrating immutability
try:
    my_tuple[0] = 10
except TypeError as e:
    print("Error:", e)  # Output: Error: 'tuple' object does not support item assignment
