pressure = 5*3**1*5
if pressure<0 :
    print("*")
elif pressure==75:
    print("**")
elif pressure<100 :
    print("***")
else:
    print("****")

print("\n")

pressure = 5*3**1*5
if pressure<0 :
    print("*")
elif pressure<75:
    print("**")
elif pressure>=75 :
    print("***")
else:
    print("****")

print("\n")
pressure = 5*3**1*5
if pressure<0 :
    print("*")
elif pressure<75:
    print("**")
elif pressure>75 :
    print("***")
else:
    print("****")

print("\n")
pressure = 5*3**1*5
if pressure<0 :
    print("*")
elif pressure>50:
    print("**")
elif pressure>75 :
    print("***")
else:
    print("****")

