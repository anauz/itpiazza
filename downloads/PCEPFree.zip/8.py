for x in range(3):
    print("*",end="")
else:
    print("-")
